#include <stdio.h>
#define p printf
#define s scanf

	int main ()
    {
        int i, j, a, n=10, number[30];
        
        p("Enter ten integers \n");
        for (i = 0; i < n; ++i)
            s("%d", &number[i]);
        
		
		
 
        for (i = 0; i < n; ++i) 
        {
 
            for (j = i + 1; j < n; ++j)
            {
 
                if (number[i] > number[j]) 
                {
 
                    a =  number[i];
                    number[i] = number[j];
                    number[j] = a;
 
                }
 
            }
 
        }
 
        p("The integers arranged in ascending order are given below \n");
        for (i = 0; i < n; ++i)
            p("%d\n", number[i]);
 
    }
