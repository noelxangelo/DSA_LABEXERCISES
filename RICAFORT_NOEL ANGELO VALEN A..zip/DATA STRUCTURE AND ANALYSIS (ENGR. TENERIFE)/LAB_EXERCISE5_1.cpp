#include<iostream>
using namespace std;

struct record{
	int id;
	string name;
	float quiz[3];
};

int main (){
	record student1;
	float grades;
	
		cout << "Enter Student Record: ";
		cout << "ID: ";
			cin >> student1.id;
		cout << "Name: ";
			cin >> student1.name;
			
		for(int x = 1; x<=3; x++){
			cout << "Quiz " << x  << ": ";
				cin >> student1.quiz[x];
		}
		grades = (student1.quiz[1]+student1.quiz[2]+student1.quiz[3])/3;
		
		cout << "\nStudent Record:\n";
		cout << "ID: " << student1.id << endl;
		cout << "Name: " << student1.name << endl;
		cout << "Grades " << grades << endl;
		
		if(grades >= 75 && grades <= 100){
			cout << "Remarks: Passed!";
		}else if(grades < 75){
			cout << "Remarks: Failed!";
		}else{
			cout << "Remarks: Over Graded!";
		}		
			
	

}
